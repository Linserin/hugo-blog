+++
date = '2026-06-10T04:48:42Z'
title = '域名上线！'
tags = ["站点日志"]

+++


昨天高考完了，今天打开疼逊云给我注册了一个域名。

一个全新域名，继续前行

```
~ $ whois linserin.work
Domain Name: linserin.work
Registry Domain ID: REDACTED FOR PRIVACY
Registrar WHOIS Server: whois.dnspod.cn
Registrar URL: www.dnspod.cn
Updated Date: 2026-06-10T03:31:49Z
Creation Date: 2026-06-10T03:19:10Z
Registry Expiry Date: 2028-06-10T03:19:10Z
Registrar: DNSPod, Inc.
Registrar IANA ID: 1697
Registrar Abuse Contact Email: dnsabuse@tencent.com
Registrar Abuse Contact Phone: +86.4009100100
Domain Status: serverTransferProhibited https://icann.org/epp#serverTransferProhibited
Domain Status: addPeriod https://icann.org/epp#addPeriod
Registry Registrant ID: REDACTED FOR PRIVACY
Registrant Name: REDACTED FOR PRIVACY
Registrant Organization: REDACTED FOR PRIVACY
Registrant Street: REDACTED FOR PRIVACY
Registrant Street: REDACTED FOR PRIVACY
Registrant Street: REDACTED FOR PRIVACY
Registrant City: REDACTED FOR PRIVACY
Registrant State/Province: guang dong sheng
Registrant Postal Code: REDACTED FOR PRIVACY
Registrant Country: CN
Registrant Phone: REDACTED FOR PRIVACY
Registrant Phone Ext: REDACTED FOR PRIVACY
Registrant Fax: REDACTED FOR PRIVACY
Registrant Fax Ext: REDACTED FOR PRIVACY
Registrant Email: Please query the RDDS service of the Registrar of Record identified in this output for information on how to contact the Registrant, Admin, or Tech contact of the queried domain name.
Registry Admin ID:
Admin Name:
Admin Organization:
Admin Street:
Admin Street:
Admin Street:
Admin City:
Admin State/Province:
Admin Postal Code:
Admin Country:
Admin Phone:
Admin Phone Ext:
Admin Fax:
Admin Fax Ext:
Admin Email:
Registry Tech ID:
Tech Name:
Tech Organization:
Tech Street:
Tech Street:
Tech Street:
Tech City:
Tech State/Province:
Tech Postal Code:
Tech Country:
Tech Phone:
Tech Phone Ext:
Tech Fax:
Tech Fax Ext:
Tech Email:
Name Server: seth.ns.cloudflare.com
Name Server: jewel.ns.cloudflare.com
DNSSEC: unsigned
URL of the ICANN Whois Inaccuracy Complaint Form: https://www.icann.org/wicf/
>>> Last update of WHOIS database: 2026-06-10T04:52:57Z <<<

For more information on Whois status codes, please visit https://icann.org/epp

The Service is provided so that you may look up certain information in relation to domain names that we store in our database.

Use of the Service is subject to our policies, in particular you should familiarise yourself with our Acceptable Use Policy and our Privacy Policy.

The information provided by this Service is 'as is' and we make no guarantee of it its accuracy.

You agree that by your use of the Service you will not use the information provided by us in a way which is:
* inconsistent with any applicable laws,
* inconsistent with any policy issued by us,
* to generate, distribute, or facilitate unsolicited mass email, promotions, advertisings or other solicitations, or
* to enable high volume, automated, electronic processes that apply to the Service.

You acknowledge that:
* a response from the Service that a domain name is 'available', does not guarantee that is able to be registered,
* we may restrict, suspend or terminate your access to the Service at any time, and
* the copying, compilation, repackaging, dissemination or other use of the information provided by the Service is not permitted, without our express written consent.

This information has been prepared and published in order to represent administrative and technical management of the TLD.

We may discontinue or amend any part or the whole of these Terms of Service from time to time at our absolute discretion.
```
